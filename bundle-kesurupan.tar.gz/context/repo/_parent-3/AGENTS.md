# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Price accuracy (Dham's rule, 2026-10-30)

For every NFT listing, price binding, and marketplace transaction: identify chain, payment token contract, token decimals (never assume — verify `decimals()` on-chain; BNB is 18), and marketplace ABI first. Convert prices with precision-safe BigInt arithmetic, never floats. Before signing or broadcasting, simulate and decode the encoded price back into human-readable units, and verify it EXACTLY matches the user's requested price and currency. If anything is uncertain or mismatched, STOP — never guess, round silently, or execute an unverified price. User price = marketplace listing price, zero tolerance for decimal/hex/price-binding errors.

## baw EIP-712 signature format (AgentsEstates, 2026-11-08)

`baw sign-message execute` returns a 64-byte signature (r+s only) plus a separate `signatureRecovery` ("00"/"01"). Servers expecting a standard 65-byte eth_signTypedData_v4 signature reject the 64-byte form (`bad_signature`). Reconstruct it by appending the v byte: v = 27 + recovery id (recovery "00" → append `1b`, "01" → `1c`), then submit as `0x` + 65-byte hex. Verified working on AgentsEstates submit_listing 2026-11-08.
